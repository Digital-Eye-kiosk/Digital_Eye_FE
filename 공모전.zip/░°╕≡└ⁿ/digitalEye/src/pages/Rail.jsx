import { useNavigate } from "react-router-dom";
import "./Rail.css";

const Rail = () => {
  const navigate = useNavigate();

  const navigateToHome = () => {
    navigate("/");
  };
  const before = () => {
    navigate("/select3");
  };
  const next = () => {
    navigate("/Recommendselect");
  };

  return (
    <div className="Select2">
      <div className="Header">
        <img src="../img/코레일.png" />
        <div className="function1">
          <button className="HB" onClick={before}>
            이전
          </button>
          <h1> 열차 시간 선택 </h1>
          <button className="HB" onClick={next}>
            다음
          </button>
        </div>
      </div>
      <div className="Main">
        <div className="function2">
          <div>
            <h5>출발역</h5>
            <h3>고정</h3>
          </div>
          <h2> > </h2>
          <div>
            <h5>도착역</h5>
            <h3>선택됨</h3>
          </div>
        </div>

        <div className="function3R">
          <div className="R">
            <div className="place">
              <h1>고정</h1>
              <h1>></h1>
              <h1>선택됨</h1>
            </div>
            <div className="data">
              <button className="RB">
                <div className="RD">
                  <div className="RD2">
                    <div className="RD3">
                      <h2 style={{ color: "#FF2F2F" }}>시간1-1</h2>
                      <h2>시간1-2</h2>
                    </div>
                    <h1 style={{ color: "#FF2F2F" }}> ></h1>
                    <div className="RD3">
                      <h2 style={{ color: "#FF2F2F" }}>시간2-1</h2>
                      <h2>시간2-2</h2>
                    </div>
                  </div>
                  <div className="RD4">
                    <div className="RD5">
                      <h2>열차칸</h2>
                      <h2>가격</h2>
                    </div>
                    <div className="RD5">
                      <h2>열차칸</h2>
                      <h2>가격</h2>
                    </div>
                  </div>
                </div>
              </button>
            </div>
          </div>
        </div>
        <div className="Footer">
          <button className="FB" onClick={navigateToHome}>
            <img src="../img/홈화면.png" height="80px" width="80px" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default Rail;
