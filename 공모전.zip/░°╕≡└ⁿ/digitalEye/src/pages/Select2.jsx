import { useNavigate } from "react-router-dom";
import "./Select.css";

const Select = () => {
  const navigate = useNavigate();

  const navigateToHome = () => {
    navigate("/");
  };
  const next = () => {
    navigate("/Calenderpick");
  };
  const before = () => {
    navigate("/select");
  };

  return (
    <div className="Select2">
      <div className="Header">
        <img src="../img/코레일.png" />
        <div className="function1">
          <button className="HB" onClick={before}>
            이전
          </button>
          <h1> 도착역 선택 </h1>
          <button className="HB" onClick={next}>
            다음
          </button>
        </div>
      </div>
      <div className="Main">
        <div className="function2">
          <div>
            <h5>출발역</h5>
            <h3>고정</h3>
          </div>
          <h2> > </h2>
          <div>
            <h5>도착역</h5>
            <h3>-</h3>
          </div>
        </div>

        <div className="function3">
          <div className="base">
            <div className="Search">
              <input placeholder="역 검색" />
              <button>검색</button>
            </div>
            <div className="Result">
              <div className="나중에 삭제 예정">
                <button className="SearchR">서울</button>
                <button className="SearchR">부산</button>
                <button className="SearchR">경기</button>
              </div>
            </div>
          </div>
        </div>
        <div className="Footer">
          <button className="FB" onClick={navigateToHome}>
            <img src="../img/홈화면.png" height="80px" width="80px" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default Select;
