import "./Select.css";
import { useNavigate } from "react-router-dom";
import "./FinalSelect.css";
import Calendar from "react-calendar";

const Finalselect = () => {
  const navigate = useNavigate();
  const before = () => {
    navigate("/Rail");
  };
  const select = () => {
    navigate("/select");
  };
  const select2 = () => {
    navigate("/select2");
  };
  const select3 = () => {
    navigate("/select3");
  };

  const calenderpick = () => {
    navigate("/calenderpick");
  };
  const ticket = () => {
    navigate("/ticket");
  };
  return (
    <div className="Finalselect">
      <div className="Header">
        <img src="../img/코레일.png" />
        <div className="function1">
          <button className="HB" onClick={before}>
            이전
          </button>
          <h1> 최종확인 </h1>
          <button className="HB"></button>
        </div>
      </div>
      <div className="Main">
        <div className="function2F">
          <h2>만약 정보가 틀리시다면 해당 버튼을 눌러 수정하십시오</h2>
          <h4>(당일결제 시 환불이 불가하오니 유의바랍니다) </h4>
        </div>

        <div className="function3F">
          <div className="BunchFB">
            <button className="FinalB" onClick={select}>
              {" "}
              지역 > 선택됨{" "}
            </button>
            <button className="FinalB" onClick={select2}>
              도착역 > 선택됨
            </button>
            <button className="FinalB" onclick={calenderpick}>
              출발일 > 선택됨
            </button>
            <button className="FinalB" onclick={ticket}>
              인원 > 선택됨
            </button>
            <button className="FinalB" onclick={select3}>
              열차 > 선택됨
            </button>
            <button className="FinalB" onclick={before}>
              열차시간 > 선택됨
            </button>
          </div>
        </div>
        <div className="Footer">
          <div className="SB2">
            <button className="FinalB2">예</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Finalselect;
